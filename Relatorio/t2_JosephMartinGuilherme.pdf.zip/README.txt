Professor para compilar javac main.javac
e para execucao java main NomeDoPrograma 
ex: java main p1.txt